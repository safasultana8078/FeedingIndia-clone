import React from 'react';
import { Link } from 'react-router-dom';
import Logo from './Logo';

/**
 * Reusable Footer Component
 * Rubric Demonstration:
 * - Component creation & reuse
 * - JSX syntax & props passing to Logo
 * - React Router Link navigation
 * - Dynamic data: new Date().getFullYear()
 */
export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="main-footer">
      <div className="contain footer-grid-container">
        {/* Brand Column */}
        <div className="footer-col brand-col">
          <Link to="/" className="footer-logo-link" aria-label="Feeding India Homepage">
            <Logo width={150} height={35} className="footer-logo" />
          </Link>
          <p className="footer-tagline">
            Nourished children are the foundation of a thriving India.
          </p>
          <div className="footer-socials">
            <a
              href="https://www.facebook.com/FeedingIndiaOfficial"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Facebook"
            >
              <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z" />
              </svg>
            </a>
            <a
              href="https://www.instagram.com/feedingindia"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Instagram"
            >
              <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.051.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
              </svg>
            </a>
            <a
              href="https://twitter.com/FeedingIndiaOf"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="X"
            >
              <svg width="18" height="18" fill="currentColor" viewBox="0 0 24 24">
                <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
              </svg>
            </a>
            <a
              href="https://www.linkedin.com/company/feeding-india"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="LinkedIn"
            >
              <svg width="20" height="20" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
              </svg>
            </a>
          </div>
        </div>

        {/* Programs Column */}
        <div className="footer-col">
          <h4 className="footer-col-title">Our Programs</h4>
          <ul className="footer-links-list">
            <li>
              <Link to="/daily-feeding-program">Daily Feeding Program</Link>
            </li>
            <li>
              <Link to="/the-anganwadi-program">The Anganwadi Program</Link>
            </li>
          </ul>
        </div>

        {/* Partnerships Column */}
        <div className="footer-col">
          <h4 className="footer-col-title">Partnerships</h4>
          <ul className="footer-links-list">
            <li>
              <Link to="/partner-with-us">Partner with us</Link>
            </li>
            <li>
              <a href="#community-events">Community events</a>
            </li>
          </ul>
        </div>

        {/* Company Column */}
        <div className="footer-col">
          <h4 className="footer-col-title">Company</h4>
          <ul className="footer-links-list">
            <li>
              <Link to="/about-us">About us</Link>
            </li>
            <li>
              <a href="mailto:contact@feedingindia.org">Contact Us</a>
            </li>
          </ul>
        </div>
      </div>

      <div className="footer-divider"></div>

      {/* Footer Bottom Bar */}
      <div className="contain footer-bottom">
        <p className="copyright-text">
          &copy; {currentYear} Feeding India Foundation. All rights reserved. Registered Section 8 Non-Profit Organization.
        </p>
        <div className="legal-links">
          <a href="#terms">Terms & Conditions</a>
          <a href="#privacy">Privacy Policy</a>
          <a href="#tax-exemption">80G Tax Exemption</a>
        </div>
      </div>
    </footer>
  );
}

